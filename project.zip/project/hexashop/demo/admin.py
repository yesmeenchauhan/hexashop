from django.contrib import admin
from . models import hexa,pay,userlog,contact,subscribe

# Register your models here.
admin.site.register(hexa)
admin.site.register(pay)
admin.site.register(userlog)
admin.site.register(contact)
admin.site.register(subscribe)

